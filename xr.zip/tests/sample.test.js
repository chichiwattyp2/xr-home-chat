import assert from 'assert';

assert.strictEqual(1 + 1, 2);
console.log('Sample test passed');

